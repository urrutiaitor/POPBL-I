

void escribirTexto(int x, int y, char *str);
