#ifndef PANTAILA0_H
#define PANTAILA0_H

typedef struct {
	int x;
	int y;
	int abiaduraX;
	int abiaduraY;
}POSIZIOA;

int PANTAILA0_nagusia();

#endif