#ifndef SARRERA_H
#define SARRERA_H

#define TITULOA "FireRock & IceBubble"
#define JOKOA "Jokoa"
#define AZALPENA "Jokoaren azalpena"
#define RANKING "Ranking-a"
#define KREDITUAK "Kredituak"
#define EXIT "Irten"

#define AUKERA0 "0. Pertsonaiaren mugimenduak probatu"
#define AUKERA1 "1. Pantaila"
#define AUKERA2 "2. Pantaila"
#define AUKERA3 "3. Pantaila"
#define AUKERA4 "4. Pantaila"
#define AUKERA5 "5. Pantaila"

#define IZENA1 "Aitor Urrutia Zubikarai"
#define IZENA2 "Ane Perez de Arenaza"
#define IZENA3 "Garbi�e Ugarte"
#define IZENA4 "Irati Alustiza"

int SARRERA_aukerakAukeratu();

#endif
