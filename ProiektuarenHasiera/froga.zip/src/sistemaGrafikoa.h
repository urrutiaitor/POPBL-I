#ifndef SISTEMA_GRAFIKOA_H
#define SISTEMA_GRAFIKOA_H

void SISTEMA_GRAFIKOA_hasieratu();
void SISTEMA_GRAFIKOA_bukatu();

#endif
