#ifndef BUKAERA_H
#define BUKAERA_H

#define JOKOA_SOUND_WIN ".\\BugleCall.wav"
#define JOKOA_SOUND_LOOSE ".\\terminator.wav" 
#define BUKAERA_SOUND_1 ".\\128NIGHT_01.wav"
#define BUKAERA_IMAGE ".\\img\\gameOver_1.bmp"

BOOLEAN  BUKAERA_menua(EGOERA egoera);

#endif