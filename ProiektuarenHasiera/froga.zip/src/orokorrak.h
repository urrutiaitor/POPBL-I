#ifndef OROKORRAK_H
#define OROKORRAK_H

typedef enum{
	FALSE, TRUE
}BOOLEAN;

typedef enum{
	JOLASTEN,
	GALDU,
	IRABAZI,
}EGOERA;

#endif
