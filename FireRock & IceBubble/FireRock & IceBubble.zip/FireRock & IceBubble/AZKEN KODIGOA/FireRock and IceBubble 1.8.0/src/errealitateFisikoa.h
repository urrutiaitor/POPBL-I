#ifndef ERREALITATE_FISIKOA_H
#define ERREALITATE_FISIKOA_H

int ERREALITATE_FISIKOA_mugimendua(int pantaila);

#endif