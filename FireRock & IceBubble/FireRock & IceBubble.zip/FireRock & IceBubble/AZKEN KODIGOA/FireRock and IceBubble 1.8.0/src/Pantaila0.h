#ifndef PANTAILA0_H
#define PANTAILA0_H

typedef struct {
	int x0;
	int y0;
	int x1;
	int y1;
	int x2;
	int y2;
	int x3;
	int y3;
	int kolorea;

}OBJETOA;

#define AZALPEN_GORRIA  ".\\irudiak\\azalpena_bola_gorria.bmp"
#define AZALPEN_URDINA ".\\irudiak\\azalpena_bola_urdina.bmp"
#define AZALPEN_PAUSA ".\\irudiak\\pausa.bmp"

void PANTAILA0_nagusia();

#endif