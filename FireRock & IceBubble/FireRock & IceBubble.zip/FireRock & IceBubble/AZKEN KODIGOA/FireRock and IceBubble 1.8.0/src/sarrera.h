#ifndef SARRERA_H
#define SARRERA_H

int SARRERA_aukerakAukeratu();

#endif
