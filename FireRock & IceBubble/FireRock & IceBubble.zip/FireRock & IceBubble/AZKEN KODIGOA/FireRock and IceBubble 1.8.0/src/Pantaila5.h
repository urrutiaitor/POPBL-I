#ifndef PANTAILA5_H
#define PANTAILA5_H


typedef struct {
	int x0;
	int y0;
	int x1;
	int y1;
	int x2;
	int y2;
	int x3;
	int y3;
	int kolorea;

}OBJETOA;

int PANTAILA5_nagusia();

#endif