#ifndef PANTAILA2_H
#define PANTAILA2_H


typedef struct {
	int x0;
	int y0;
	int x1;
	int y1;
	int x2;
	int y2;
	int x3;
	int y3;
	int kolorea;

}OBJETOA;

void PANTAILA2_nagusia();

#endif