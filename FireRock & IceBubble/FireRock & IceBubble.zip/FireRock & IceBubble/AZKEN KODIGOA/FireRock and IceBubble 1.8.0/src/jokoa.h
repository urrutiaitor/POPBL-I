#ifndef JOKOA_H
#define JOKOA_H

typedef enum{IRUDIA, MARGOA, TESTUA}MOTA;


EGOERA JOKOA_jokoa();

#endif