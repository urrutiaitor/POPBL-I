#include "SDL.h"
typedef SDL_Surface* Imagen;